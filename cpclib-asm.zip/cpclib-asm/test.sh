../target/debug/basm tests/asm/arkos/plasmaminus.asm --sna -o plasmaminus.sna
../target/debug/basm tests/asm/arkos/twither.asm --sna -o twither.sna